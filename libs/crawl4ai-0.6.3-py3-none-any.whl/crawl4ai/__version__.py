# crawl4ai/_version.py
__version__ = "0.6.3"

