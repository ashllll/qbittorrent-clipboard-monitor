from ._stealth_config import BrowserType, StealthConfig

__all__ = ["StealthConfig", "BrowserType"]
