from ._properties import BrowserType, Properties

__all__ = ["Properties", "BrowserType"]
